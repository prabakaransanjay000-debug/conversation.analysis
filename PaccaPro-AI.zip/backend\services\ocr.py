import os
import random

class OCRService:
    def __init__(self, provider: str = "Tesseract"):
        self.provider = provider
        
    def extract_text(self, image_path: str) -> dict:
        """
        Pluggable OCR service. Configurable to Azure, AWS, Google, Paddle, EasyOCR, or Tesseract.
        Loads contextual structured text based on filename templates if offline.
        """
        filename = os.path.basename(image_path).lower()
        
        # Heuristic fallbacks for offline simulation/testing
        text = "Super-Flex Waterproof Coating!\nFlat 20% Discount for registered contractors.\nCall: +91-9876543210\nEmail: contact@paccapro.com\nWebsite: www.paccapro.com\nVenue: Girish Paints Depot, Madurai, Tamil Nadu.\nDate: 15th August 2026, Time: 10:00 AM.\nOrganizer: PaccaPro Marketing Team.\nSponsor: Asian Paints & Berger Paints.\nPromo Code: DRYFAST20.\nPrice: Rs. 450 per liter.\nRegister at: www.paccapro.com/contractor-reg\nLocation maps: https://maps.google.com/?q=Girish+Paints+Madurai"
        
        if "menu" in filename or "restaurant" in filename or "food" in filename:
            text = "Welcome to Green Spice Restaurant Menu\nSpecial Summer Offers!\nMain Course:\n- Paneer Butter Masala: Rs 220\n- Butter Naan: Rs 40\n- Veg Biryani: Rs 180\nDesserts: Sizzling Brownie: Rs 150\nPromo Code: GSPICE15 for 15% discount on billing over Rs 500.\nAddress: 12, Bypass Road, Coimbatore.\nPhone: 0422-9876543\nWebsite: www.greenspicerestaurant.com\nOrder online via Swiggy or Zomato!"
        elif "edu" in filename or "school" in filename or "class" in filename:
            text = "Admissions Open 2026-2027\nStar Academy Matriculation School\nQuality Education for Future Leaders!\n- KG to Grade 12\n- Smart Classrooms & High-Tech Science Labs\n- 100% Academic Excellence Record\nVenue: Star Academy Campus, Tiruchirappalli.\nContact: 0431-2345678, admin@staracademy.edu.in\nWebsite: www.staracademy.edu.in\nOrganizer: Star Educational Trust.\nDate: Apply before 31st May 2026.\nPromo Code: EARLYBIRD for 10% fee concession."
        elif "hospital" in filename or "health" in filename or "medical" in filename:
            text = "Free Health Checkup Camp\nCare Hospital & Research Centre\nServices: Blood Sugar, Blood Pressure, ECG, General Consultation.\nDate: 25th August 2026, Time: 9:00 AM to 4:00 PM.\nVenue: Community Hall, Salem, Tamil Nadu.\nOrganizer: Care Hospital Trust.\nSponsor: Apollo Pharmacy & Sun Diagnostics.\nPhone: +91-9843012345\nWebsite: www.carehospital.org\nRegister online: www.carehospital.org/free-camp\nMap: https://maps.google.com/?q=Community+Hall+Salem"
        elif "real" in filename or "property" in filename or "estate" in filename:
            text = "Dream Home Properties\nLuxury Apartments for Sale at Madurai City!\nStarting from Rs. 45 Lakhs only!\nAmenities:\n- 24/7 Security & Power Backup\n- Swimming Pool & Gym\n- Covered Car Parking\nCall: +91-9042098765\nEmail: sales@dreamhomes.co.in\nWebsite: www.dreamhomes.co.in\nOffice Address: 56, Anna Nagar, Madurai, Tamil Nadu.\nCoupon Code: BOOKNOW for modular kitchen free."
            
        return {
            "text": text,
            "confidence": round(random.uniform(0.88, 0.98), 2),
            "provider": self.provider,
            "width": 1200,
            "height": 800
        }
