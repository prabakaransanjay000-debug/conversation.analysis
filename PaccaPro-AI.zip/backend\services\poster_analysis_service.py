import re
import hashlib
import json
import datetime
from sqlalchemy.orm import Session
from backend.models import PosterAnalysis
from backend.services.ocr import OCRService

class PosterAnalysisService:
    def __init__(self, db: Session, provider: str = "Tesseract"):
        self.db = db
        self.ocr_service = OCRService(provider=provider)

    def compute_sha256(self, file_bytes: bytes) -> str:
        """
        Compute SHA-256 hash of image bytes to prevent duplicate uploads.
        """
        return hashlib.sha256(file_bytes).hexdigest()

    def check_duplicate(self, image_hash: str) -> bool:
        """
        Returns true if the image hash is already registered in the DB.
        """
        return self.db.query(PosterAnalysis).filter(PosterAnalysis.image_hash == image_hash).first() is not None

    def get_by_hash(self, image_hash: str) -> PosterAnalysis:
        return self.db.query(PosterAnalysis).filter(PosterAnalysis.image_hash == image_hash).first()

    def run_analysis(self, image_path: str, filename: str, image_hash: str, uploaded_by: str) -> PosterAnalysis:
        """
        Runs OCR text extraction, generates structured analysis metrics,
        and saves everything to the database.
        """
        # Run OCR Service
        ocr_result = self.ocr_service.extract_text(image_path)
        ocr_text = ocr_result["text"]
        ocr_conf = ocr_result["confidence"]

        # Parse Category Heuristic
        category = "Marketing"
        text_lower = ocr_text.lower()
        if any(w in text_lower for w in ["menu", "spicy", "biryani", "veg", "food", "dessert"]):
            category = "Restaurant"
        elif any(w in text_lower for w in ["school", "academy", "admissions", "education", "grade"]):
            category = "Education"
        elif any(w in text_lower for w in ["hospital", "clinic", "health", "doctor", "medical", "checkup"]):
            category = "Healthcare"
        elif any(w in text_lower for w in ["apartment", "sale", "rent", "flat", "real estate", "property"]):
            category = "Real Estate"
        elif any(w in text_lower for w in ["conference", "summit", "webinar", "seminar"]):
            category = "Conference"
        elif any(w in text_lower for w in ["festival", "celebration", "diwali", "christmas", "temple"]):
            category = "Festival"

        # Headings
        lines = [line.strip() for line in ocr_text.split("\n") if line.strip()]
        title = lines[0] if len(lines) > 0 else "Untitled Poster"
        main_heading = lines[0] if len(lines) > 0 else ""
        sub_heading = lines[1] if len(lines) > 1 else ""

        # Regular Expression Extractions
        emails = re.findall(r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}', ocr_text)
        phones = re.findall(r'\+?\d[\d\s()-]{8,14}\d', ocr_text)
        urls = re.findall(r'www\.[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}|https?://[a-zA-Z0-9./?=&_-]+', ocr_text)
        
        # Clean extracted lists
        emails = list(set(emails))
        phones = list(set([p.strip() for p in phones if len(p.strip()) >= 10]))
        urls = list(set(urls))

        # Venue / Address
        venue = "N/A"
        venue_match = re.search(r'(?:venue|address|office|location):\s*([^\n]+)', ocr_text, re.IGNORECASE)
        if venue_match:
            venue = venue_match.group(1).strip()
        elif "address:" in text_lower:
            addr_idx = text_lower.find("address:")
            venue = ocr_text[addr_idx + 8:].split("\n")[0].strip()

        # Date & Time
        date_val = "N/A"
        time_val = "N/A"
        date_match = re.search(r'(?:date|on):\s*([^\n,]+)', ocr_text, re.IGNORECASE)
        if date_match:
            date_val = date_match.group(1).strip()
        time_match = re.search(r'(?:time|at):\s*([^\n]+)', ocr_text, re.IGNORECASE)
        if time_match:
            time_val = time_match.group(1).strip()

        # Organizer / Sponsors
        organizer = "N/A"
        org_match = re.search(r'(?:organizer|organized by):\s*([^\n]+)', ocr_text, re.IGNORECASE)
        if org_match:
            organizer = org_match.group(1).strip()
        elif "organizer:" in text_lower:
            org_idx = text_lower.find("organizer:")
            organizer = ocr_text[org_idx + 10:].split("\n")[0].strip()

        sponsors = []
        spons_match = re.search(r'(?:sponsor|sponsors|sponsored by):\s*([^\n]+)', ocr_text, re.IGNORECASE)
        if spons_match:
            sponsors = [s.strip() for s in spons_match.group(1).split("&")]

        # Discounts / Offers / Promo Codes / Pricing
        discount = "None"
        disc_match = re.search(r'(\d+%\s*(?:discount|off))', ocr_text, re.IGNORECASE)
        if disc_match:
            discount = disc_match.group(1).strip()

        coupon = "None"
        coup_match = re.search(r'(?:promo|coupon|code):\s*([A-Z0-9_-]+)', ocr_text, re.IGNORECASE)
        if coup_match:
            coupon = coup_match.group(1).strip()
        elif "promo code:" in text_lower:
            p_idx = text_lower.find("promo code:")
            coupon = ocr_text[p_idx + 11:].split("\n")[0].split(" ")[0].strip()

        price = "N/A"
        price_match = re.search(r'(?:price|rs\.?|inr|\$)\s*([\d,]+)', ocr_text, re.IGNORECASE)
        if price_match:
            price = price_match.group(0).strip()

        # Map links
        maps_link = ""
        maps_match = re.search(r'(https?://maps\.[^\s]+|https?://[^\s]*maps[^\s]*)', ocr_text, re.IGNORECASE)
        if maps_match:
            maps_link = maps_match.group(1).strip()

        # Sentiment, Tone, Target Audience
        sentiment = "Positive"
        tone = "Professional"
        audience = "General Public"
        cta = "Visit our website or contact us to register!"

        if category == "Restaurant":
            audience = "Food lovers, local families, and diner clients"
            tone = "Warm & Inviting"
            cta = "Order online via Swiggy or Zomato, or dine in today!"
        elif category == "Education":
            audience = "Parents, students, and academic aspirants"
            tone = "Academic & Trustworthy"
            cta = "Admissions open. Contact registrar or apply before deadline!"
        elif category == "Healthcare":
            audience = "Patients, local residents seeking medical screenings"
            tone = "Caring & Reassuring"
            cta = "Register online for the free screening camp today!"
        elif category == "Real Estate":
            audience = "Home buyers, property investors, and families"
            tone = "Premium & Sales-focused"
            cta = "Book now to receive modular kitchen layout free!"
        elif "waterproof" in text_lower or "coating" in text_lower or "paint" in text_lower:
            audience = "Construction contractors, painters, and site managers"
            tone = "Technical & Promotional"
            cta = "Call register for contractor discount code!"

        # Keywords Heuristics
        keywords = ["Marketing", category]
        if emails: keywords.append("Contact")
        if discount != "None": keywords.append("Offer")
        if coupon != "None": keywords.append("Promo")

        # Highlights & Summaries
        summary = f"A {category} promotional poster titled '{title}' emphasizing key features and pricing."
        detailed_summary = f"This marketing banner contains detailed copy regarding {title}. It targets {audience} with a {tone.lower()} tone. Key promotions include {discount} with promo code '{coupon}'."
        
        highlights = [
            f"Promotes {title} in the {category} segment.",
            f"Targets {audience} directly.",
            f"Offers {discount if discount != 'None' else 'standard prices'} for early registration."
        ]

        # Suggestion engine
        suggestions = []
        if not cta or len(cta) < 15:
            suggestions.append("Weak CTA: The poster lacks a highly visible action directive for conversions.")
        if not emails and not phones:
            suggestions.append("Missing contact details: Include clear phone numbers or support emails.")
        if len(ocr_text) > 400:
            suggestions.append("Too much text: Consider reducing descriptions to improve negative space balance.")
        if discount == "None" and coupon == "None":
            suggestions.append("Missing offer details: Adding a time-bounded coupon code can trigger FOMO.")
        if ocr_conf < 0.9:
            suggestions.append("Poor readability: Some text elements are printed in low-contrast font styles.")

        if not suggestions:
            suggestions = [
                "Maintain current marketing layouts; visual hierarchy is clean.",
                "Ensure map locations are embedded in printed QR codes."
            ]

        # Wrap into JSON strings/Dict structures
        important_info = {
            "emails": emails,
            "phones": phones,
            "urls": urls,
            "venue": venue,
            "date": date_val,
            "time": time_val,
            "organizer": organizer,
            "sponsors": sponsors,
            "discount": discount,
            "coupon_code": coupon,
            "price": price,
            "maps_link": maps_link
        }

        # Create Model Instance
        analysis = PosterAnalysis(
            poster_title=title,
            poster_category=category,
            main_heading=main_heading,
            sub_heading=sub_heading,
            filename=filename,
            image_url=f"/uploads/posters/{filename}",
            image_hash=image_hash,
            ocr_text=ocr_text,
            summary=summary,
            detailed_summary=detailed_summary,
            highlights=json.dumps(highlights),
            important_information=json.dumps(important_info),
            keywords=json.dumps(keywords),
            language="English",
            sentiment=sentiment,
            tone=tone,
            target_audience=audience,
            call_to_action=cta,
            ocr_confidence=ocr_conf,
            ai_confidence=0.95,
            uploaded_by=uploaded_by
        )

        self.db.add(analysis)
        self.db.commit()
        self.db.refresh(analysis)
        return analysis
