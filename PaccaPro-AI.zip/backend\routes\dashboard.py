import datetime
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from sqlalchemy import func
from backend.database import get_db
from backend.utils import get_current_user, logger
from backend.models import Report, Sales, VoiceFile

router = APIRouter(tags=["dashboard"])

def get_date_limits():
    today = datetime.date.today()
    today_str = today.strftime("%Y-%m-%d")
    
    # Start of this week (Monday)
    start_of_week = today - datetime.timedelta(days=today.weekday())
    start_of_week_str = start_of_week.strftime("%Y-%m-%d")
    
    # Start of this month
    start_of_month_str = today.replace(day=1).strftime("%Y-%m-%d")
    
    # Start of this year
    start_of_year_str = today.replace(month=1, day=1).strftime("%Y-%m-%d")
    
    return today_str, start_of_week_str, start_of_month_str, start_of_year_str

@router.get("/dashboard")
def get_dashboard_data(db: Session = Depends(get_db), current_user: str = Depends(get_current_user)):
    """
    Returns card counts, representative tables, and Chart.js datasets.
    """
    logger.info("Fetching dashboard data")
    today_str, start_of_week, start_of_month, start_of_year = get_date_limits()
    
    # Card 1: Total Reports
    total_reports = db.query(Report).count()
    
    # Card 2: Today's Reports
    today_reports = db.query(Report).filter(Report.date == today_str).count()
    
    # Card 3: Weekly Reports (last 7 calendar days)
    seven_days_ago = (datetime.date.today() - datetime.timedelta(days=7)).strftime("%Y-%m-%d")
    weekly_reports = db.query(Report).filter(Report.date >= seven_days_ago).count()
    
    # Card 4: Monthly Reports
    monthly_reports = db.query(Report).filter(Report.date >= start_of_month).count()
    
    # Card 5: Yearly Reports
    yearly_reports = db.query(Report).filter(Report.date >= start_of_year).count()
    
    # --- Sales Representative Table ---
    # We need: Sales Rep, Today's, Weekly, Monthly, Yearly Performance (sales amounts)
    rep_list = [
        "Santhana Pandiyan",
        "Periyar Selvam",
        "Bala Murugan",
        "Rajeshwaran",
        "Vinoth Kumar",
        "Parthiban",
        "Sri Ram"
    ]
    
    rep_table = []
    for rep in rep_list:
        # Today
        today_sales = db.query(func.sum(Sales.amount))\
            .join(Report)\
            .filter(Report.representative == rep, Report.date == today_str)\
            .scalar() or 0.0
            
        # Weekly (last 7 days)
        weekly_sales = db.query(func.sum(Sales.amount))\
            .join(Report)\
            .filter(Report.representative == rep, Report.date >= seven_days_ago)\
            .scalar() or 0.0
            
        # Monthly
        monthly_sales = db.query(func.sum(Sales.amount))\
            .join(Report)\
            .filter(Report.representative == rep, Report.date >= start_of_month)\
            .scalar() or 0.0
            
        # Yearly
        yearly_sales = db.query(func.sum(Sales.amount))\
            .join(Report)\
            .filter(Report.representative == rep, Report.date >= start_of_year)\
            .scalar() or 0.0
            
        rep_table.append({
            "representative": rep,
            "today_performance": today_sales,
            "weekly_performance": weekly_sales,
            "monthly_performance": monthly_sales,
            "yearly_performance": yearly_sales
        })
        
    # Sort representatives by yearly performance descending
    rep_table = sorted(rep_table, key=lambda x: x["yearly_performance"], reverse=True)

    # --- Chart.js Data Aggregations ---
    # 1. Daily Graph (Sales in last 7 days)
    daily_labels = []
    daily_sales = []
    for i in range(6, -1, -1):
        day = datetime.date.today() - datetime.timedelta(days=i)
        day_str = day.strftime("%Y-%m-%d")
        daily_labels.append(day.strftime("%a (%d %b)"))
        
        sales_val = db.query(func.sum(Sales.amount))\
            .join(Report)\
            .filter(Report.date == day_str)\
            .scalar() or 0.0
        daily_sales.append(sales_val)
        
    # 2. Weekly Graph (Sales in last 4 weeks)
    weekly_labels = []
    weekly_sales_data = []
    for i in range(3, -1, -1):
        # 7-day intervals
        end_day = datetime.date.today() - datetime.timedelta(days=i*7)
        start_day = end_day - datetime.timedelta(days=6)
        start_str = start_day.strftime("%Y-%m-%d")
        end_str = end_day.strftime("%Y-%m-%d")
        
        weekly_labels.append(f"Wk -{i}" if i > 0 else "This Wk")
        sales_val = db.query(func.sum(Sales.amount))\
            .join(Report)\
            .filter(Report.date >= start_str, Report.date <= end_str)\
            .scalar() or 0.0
        weekly_sales_data.append(sales_val)

    # 3. Monthly Graph (Sales in last 6 months)
    monthly_labels = []
    monthly_sales_data = []
    current_month_date = datetime.date.today().replace(day=1)
    for i in range(5, -1, -1):
        # Subtract months
        target_month_date = current_month_date
        for _ in range(i):
            # Safe subtract
            first_of_target = target_month_date.replace(day=1)
            target_month_date = (first_of_target - datetime.timedelta(days=1)).replace(day=1)
            
        m_str = target_month_date.strftime("%Y-%m")
        monthly_labels.append(target_month_date.strftime("%b %Y"))
        
        sales_val = db.query(func.sum(Sales.amount))\
            .join(Report)\
            .filter(Report.date.like(f"{m_str}%"))\
            .scalar() or 0.0
        monthly_sales_data.append(sales_val)
        
    # 4. Yearly Graph (Sales in last 3 years)
    this_year = datetime.date.today().year
    yearly_labels = [str(this_year - 2), str(this_year - 1), str(this_year)]
    yearly_sales_data = []
    for yr in yearly_labels:
        sales_val = db.query(func.sum(Sales.amount))\
            .join(Report)\
            .filter(Report.date.like(f"{yr}%"))\
            .scalar() or 0.0
        yearly_sales_data.append(sales_val)

    # 5. Sales Representative Comparison
    rep_comparison_labels = []
    rep_comparison_sales = []
    for rep in rep_list:
        rep_comparison_labels.append(rep)
        sales_val = db.query(func.sum(Sales.amount))\
            .join(Report)\
            .filter(Report.representative == rep)\
            .scalar() or 0.0
        rep_comparison_sales.append(sales_val)

    # 6. Voice Upload Count per rep
    rep_upload_counts = []
    for rep in rep_list:
        up_count = db.query(VoiceFile).join(Report).filter(Report.representative == rep).count()
        rep_upload_counts.append(up_count)

    # 7. Average Voice Duration per rep
    rep_avg_durations = []
    for rep in rep_list:
        avg_dur = db.query(func.avg(Report.voice_duration)).filter(Report.representative == rep).scalar() or 0.0
        rep_avg_durations.append(round(avg_dur, 1))

    # 8. Client Count per rep
    rep_client_counts = []
    for rep in rep_list:
        c_count = db.query(Report.client_name).filter(Report.representative == rep).distinct().count()
        rep_client_counts.append(c_count)

    return {
        "cards": {
            "total_reports": total_reports,
            "today_reports": today_reports,
            "weekly_reports": weekly_reports,
            "monthly_reports": monthly_reports,
            "yearly_reports": yearly_reports
        },
        "rep_table": rep_table,
        "charts": {
            "daily": {
                "labels": daily_labels,
                "data": daily_sales
            },
            "weekly": {
                "labels": weekly_labels,
                "data": weekly_sales_data
            },
            "monthly": {
                "labels": monthly_labels,
                "data": monthly_sales_data
            },
            "yearly": {
                "labels": yearly_labels,
                "data": yearly_sales_data
            },
            "rep_comparison": {
                "labels": rep_comparison_labels,
                "data": rep_comparison_sales
            },
            "rep_uploads": {
                "labels": rep_comparison_labels,
                "data": rep_upload_counts
            },
            "rep_durations": {
                "labels": rep_comparison_labels,
                "data": rep_avg_durations
            },
            "rep_clients": {
                "labels": rep_comparison_labels,
                "data": rep_client_counts
            }
        }
    }

@router.get("/statistics")
def get_statistics(db: Session = Depends(get_db), current_user: str = Depends(get_current_user)):
    """
    Returns general stats summary.
    """
    from backend.models import Collection, Complaint
    total_sales = db.query(func.sum(Sales.amount)).scalar() or 0.0
    total_collections = db.query(func.sum(Collection.amount_collected)).scalar() or 0.0
    total_complaints = db.query(Complaint).count()
    resolved_complaints = db.query(Complaint).filter(Complaint.status == "Resolved").count()
    
    return {
        "total_sales": total_sales,
        "total_collections": total_collections,
        "total_complaints": total_complaints,
        "resolved_complaints": resolved_complaints
    }

@router.get("/sales-representatives")
def get_sales_representatives(db: Session = Depends(get_db), current_user: str = Depends(get_current_user)):
    """
    Returns list of distinct sales representatives.
    """
    reps = db.query(Report.representative).distinct().all()
    rep_list = [r[0] for r in reps if r[0]]
    if not rep_list:
        rep_list = [
            "Santhana Pandiyan",
            "Periyar Selvam",
            "Bala Murugan",
            "Rajeshwaran",
            "Vinoth Kumar",
            "Parthiban",
            "Sri Ram"
        ]
    return rep_list
