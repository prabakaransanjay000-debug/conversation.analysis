import re
from datetime import date
from sqlalchemy.orm import Session
from backend.models import Report, Complaint, Collection, Sales

class ChatService:
    def __init__(self):
        pass

    def process_message(self, db: Session, message: str) -> str:
        """
        Processes a chat query. Matches user intents with database actions
        to return dynamic responses based on live database records.
        """
        msg_lower = message.lower()
        today_str = date.today().strftime("%Y-%m-%d")

        # 1. Intent: Complaints
        if "complaint" in msg_lower:
            complaints = db.query(Complaint).join(Report).all()
            if not complaints:
                return "There are no complaints registered in the system right now."
            
            reply = "Here are the registered complaints in the system:\n\n"
            reply += "| Rep | Client | Complaint Details | Severity | Status |\n"
            reply += "| --- | --- | --- | --- | --- |\n"
            for c in complaints:
                reply += f"| {c.report.representative} | {c.report.client_name} | {c.description} | **{c.severity}** | `{c.status}` |\n"
            return reply

        # 2. Intent: Today's reports
        if "today's reports" in msg_lower or "reports today" in msg_lower:
            # Query reports for today
            reports = db.query(Report).filter(Report.date == today_str).all()
            if not reports:
                return f"No reports have been submitted today ({today_str}) yet."
            
            reply = f"Here are the reports submitted today ({today_str}):\n\n"
            reply += "| Rep | Client | Summary | Sentiment | Priority |\n"
            reply += "| --- | --- | --- | --- | --- |\n"
            for r in reports:
                reply += f"| {r.representative} | {r.client_name} | {r.summary or 'No summary'} | {r.sentiment} | {r.priority} |\n"
            return reply

        # 3. Intent: Today's collections or list collections
        if "collection" in msg_lower:
            collections = db.query(Collection).join(Report).all()
            if "today" in msg_lower:
                collections = [c for c in collections if c.report.date == today_str]
                
            if not collections:
                return "No payment collections were found matching your request."
                
            reply = "Here is the summary of payment collections:\n\n"
            reply += "| Rep | Client | Amount | Method | Reference |\n"
            reply += "| --- | --- | --- | --- | --- |\n"
            total = 0.0
            for c in collections:
                total += c.amount_collected
                reply += f"| {c.report.representative} | {c.report.client_name} | INR {c.amount_collected:,.2f} | {c.payment_method or 'N/A'} | {c.reference_no or 'N/A'} |\n"
            reply += f"\n**Total Collected: INR {total:,.2f}**"
            return reply

        # 4. Intent: Balaji's clients/reports or Suresh's reports
        for name in ["balaji", "suresh", "kumar"]:
            if name in msg_lower:
                # Search by representative or client name
                reports = db.query(Report).filter(
                    (Report.representative.ilike(f"%{name}%")) | 
                    (Report.client_name.ilike(f"%{name}%"))
                ).all()
                
                if not reports:
                    return f"I couldn't find any reports matching '{name}'."
                
                reply = f"Here are the sales records matching **{name.capitalize()}**:\n\n"
                reply += "| Date | Rep | Client | Key Actions / Summary | Sentiment |\n"
                reply += "| --- | --- | --- | --- | --- |\n"
                for r in reports:
                    reply += f"| {r.date} | {r.representative} | {r.client_name} | {r.summary} | {r.sentiment} |\n"
                return reply

        # 5. Intent: Compare monthly/yearly performance
        if "compare" in msg_lower or "performance" in msg_lower:
            sales_data = db.query(Sales).join(Report).all()
            if not sales_data:
                return "There is no sales performance data to compare yet. Please upload reports."
            
            # Aggregate sales by Representative
            rep_performance = {}
            for s in sales_data:
                rep = s.report.representative
                rep_performance[rep] = rep_performance.get(rep, 0.0) + s.amount
                
            reply = "Here is the sales performance comparison by Representative:\n\n"
            reply += "| Sales Representative | Cumulative Booked Sales |\n"
            reply += "| --- | --- |\n"
            for rep, total in sorted(rep_performance.items(), key=lambda x: x[1], reverse=True):
                reply += f"| **{rep}** | INR {total:,.2f} |\n"
            return reply

        # 6. Fallback conversational response
        return (
            f"Hello! I am your PaccaPro AI Assistant. I operate offline and have direct access to your local SQLite sales data.\n\n"
            f"Here are some examples of what you can ask me:\n"
            f"- *'Show today's reports'* (checks reports submitted on {today_str})\n"
            f"- *'List all collections'* (summarizes client payment records)\n"
            f"- *'Show Balaji's clients'* (filters by representative or client name)\n"
            f"- *'Show all complaints'* (displays unresolved client complaints)\n"
            f"- *'Compare performance'* (calculates sales performance by rep)\n\n"
            f"Please let me know how I can help you analyze the sales data!"
        )
