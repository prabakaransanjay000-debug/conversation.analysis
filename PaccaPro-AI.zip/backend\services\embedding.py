import random

class EmbeddingService:
    def __init__(self, model_name: str = "all-MiniLM-L6-v2"):
        self.model_name = model_name

    def get_embedding(self, text: str) -> list:
        """
        Generates a text embedding vector (placeholder).
        Returns a mock 384-dimension vector normalized.
        """
        # Seed by text hash to have consistent embeddings for same text
        val = sum(ord(c) for c in text)
        random.seed(val)
        
        vector = [random.uniform(-1.0, 1.0) for _ in range(384)]
        # Normalize vector
        sq_sum = sum(v*v for v in vector)
        norm = sq_sum ** 0.5
        if norm > 0:
            vector = [v / norm for v in vector]
            
        return vector
